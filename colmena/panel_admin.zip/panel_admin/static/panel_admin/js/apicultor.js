document.addEventListener("DOMContentLoaded", function () {
 
    /* =========================================================
       ELEMENTOS DEL FORMULARIO
    ========================================================= */
 
    const formularioAgregar = document.getElementById(
        "formAgregarApicultor"
    );
 
    const inputFotoAgregar = document.getElementById(
        "fotoperfilAgregar"
    );
 
    const imagenPreviewAgregar = document.getElementById(
        "imagenPreviewAgregar"
    );
 
    const iconoPreviewAgregar = document.getElementById(
        "iconoPreviewAgregar"
    );
 
    const botonQuitarFoto = document.getElementById(
        "btnQuitarFotoAgregar"
    );
 
    const passwordAgregar = document.getElementById(
        "passwordAgregar"
    );
 
    const confirmarPasswordAgregar = document.getElementById(
        "confirmarPasswordAgregar"
    );
 
    const mensajePasswordNoCoincide = document.getElementById(
        "mensajePasswordNoCoincide"
    );

    const mensajePasswordSeguridadAgregar = document.getElementById(
        "mensajePasswordSeguridadAgregar"
    );
 
    const botonGuardarApicultor = document.getElementById(
        "btnGuardarApicultor"
    );
 
    const modalAgregarElemento = document.getElementById(
        "modalAgregarApicultor"
    );

    const usernameAgregarPassword = document.getElementById(
        "usernameAgregar"
    );

    const correoAgregarPassword = document.getElementById(
        "correoAgregar"
    );

    const primerNombreAgregarPassword = document.getElementById(
        "primerNombreAgregar"
    );

    const primerApellidoAgregarPassword = document.getElementById(
        "primerApellidoAgregar"
    );


    let temporizadorPasswordApicultor =
        null;


    let secuenciaPasswordApicultor =
        0;


    if (passwordAgregar) {

        passwordAgregar.dataset.passwordValidado =
            "0";

        passwordAgregar.dataset.passwordVerificando =
            "0";

    }

    function actualizarBotonRegistroApicultor() {

        if (
            !formularioAgregar ||
            !botonGuardarApicultor
        ) {

            return;
        }


        const hayDuplicado =
            formularioAgregar.querySelector(
                '[data-duplicado="1"]'
            );

        const hayVerificando =
            formularioAgregar.querySelector(
                '[data-verificando="1"]'
            );


        const passwordVerificando =
            Boolean(
                passwordAgregar &&
                passwordAgregar.dataset.passwordVerificando === "1"
            );


        const passwordValidado =
            Boolean(
                passwordAgregar &&
                passwordAgregar.dataset.passwordValidado === "1"
            );


        const passwordsCoinciden =
            Boolean(
                passwordAgregar &&
                confirmarPasswordAgregar &&
                passwordAgregar.value &&
                confirmarPasswordAgregar.value &&
                passwordAgregar.value ===
                    confirmarPasswordAgregar.value
            );


        const formularioValido =
            formularioAgregar.checkValidity();


        botonGuardarApicultor.disabled =
            !(
                formularioValido &&
                !hayDuplicado &&
                !hayVerificando &&
                !passwordVerificando &&
                passwordValidado &&
                passwordsCoinciden
            );

    }

    actualizarBotonRegistroApicultor();

    if (formularioAgregar) {

        const observadorEstadoValidaciones =
            new MutationObserver(
                actualizarBotonRegistroApicultor
            );


        observadorEstadoValidaciones.observe(
            formularioAgregar,
            {
                subtree: true,
                attributes: true,
                attributeFilter: [
                    "data-duplicado",
                    "data-verificando"
                ]
            }
        );

    }
 
    /* =========================================================
       MOSTRAR Y OCULTAR CONTRASEÑAS
    ========================================================= */
 
    const botonesMostrarPassword = document.querySelectorAll(
        ".btn-mostrar-password"
    );
 
    botonesMostrarPassword.forEach(function (boton) {
 
        boton.addEventListener("click", function () {
 
            const idInput = boton.dataset.passwordTarget;
            const inputPassword = document.getElementById(idInput);
            const icono = boton.querySelector("i");
 
            if (!inputPassword || !icono) {
                return;
            }
 
            if (inputPassword.type === "password") {
 
                inputPassword.type = "text";
 
                icono.classList.remove("bi-eye-fill");
                icono.classList.add("bi-eye-slash-fill");
 
                boton.setAttribute(
                    "aria-label",
                    "Ocultar contraseña"
                );
 
                boton.setAttribute(
                    "title",
                    "Ocultar contraseña"
                );
 
            } else {
 
                inputPassword.type = "password";
 
                icono.classList.remove("bi-eye-slash-fill");
                icono.classList.add("bi-eye-fill");
 
                boton.setAttribute(
                    "aria-label",
                    "Mostrar contraseña"
                );
 
                boton.setAttribute(
                    "title",
                    "Mostrar contraseña"
                );
 
            }
 
        });
 
    });
 
 
    /* =========================================================
       VISTA PREVIA DE FOTO
    ========================================================= */
 
    if (inputFotoAgregar) {
 
        inputFotoAgregar.addEventListener("change", function () {
 
            const archivo = inputFotoAgregar.files[0];
 
            if (!archivo) {
                limpiarVistaPreviaAgregar();
                return;
            }
 
            const tiposPermitidos = [
                "image/jpeg",
                "image/png",
                "image/webp"
            ];
 
            if (!tiposPermitidos.includes(archivo.type)) {
 
                alert(
                    "Selecciona una imagen en formato JPG, PNG o WEBP."
                );
 
                inputFotoAgregar.value = "";
                limpiarVistaPreviaAgregar();
 
                return;
            }
 
            const tamanoMaximo = 5 * 1024 * 1024;
 
            if (archivo.size > tamanoMaximo) {
 
                alert(
                    "La imagen no puede superar los 5 MB."
                );
 
                inputFotoAgregar.value = "";
                limpiarVistaPreviaAgregar();
 
                return;
            }
 
            const lector = new FileReader();
 
            lector.addEventListener("load", function (evento) {
 
                if (!imagenPreviewAgregar) {
                    return;
                }
 
                imagenPreviewAgregar.src = evento.target.result;
                imagenPreviewAgregar.classList.remove("d-none");
 
                if (iconoPreviewAgregar) {
                    iconoPreviewAgregar.classList.add("d-none");
                }
 
                if (botonQuitarFoto) {
                    botonQuitarFoto.classList.remove("d-none");
                }
 
            });
 
            lector.readAsDataURL(archivo);
 
        });
 
    }
 
 
    /* =========================================================
       QUITAR FOTO SELECCIONADA
    ========================================================= */
 
    if (botonQuitarFoto) {
 
        botonQuitarFoto.addEventListener("click", function () {
 
            if (inputFotoAgregar) {
                inputFotoAgregar.value = "";
            }
 
            limpiarVistaPreviaAgregar();
 
        });
 
    }
 
 
    function limpiarVistaPreviaAgregar() {
 
        if (imagenPreviewAgregar) {
 
            imagenPreviewAgregar.src = "";
            imagenPreviewAgregar.classList.add("d-none");
 
        }
 
        if (iconoPreviewAgregar) {
            iconoPreviewAgregar.classList.remove("d-none");
        }
 
        if (botonQuitarFoto) {
            botonQuitarFoto.classList.add("d-none");
        }
 
    }
 
 
    /* =========================================================
       VALIDAR QUE LAS CONTRASEÑAS COINCIDAN
    ========================================================= */
 
    function validarContrasenas() {
 
        if (
            !passwordAgregar ||
            !confirmarPasswordAgregar ||
            !mensajePasswordNoCoincide
        ) {
            return true;
        }
 
        const password = passwordAgregar.value;
        const confirmacion = confirmarPasswordAgregar.value;
 
        if (!confirmacion) {
 
            mensajePasswordNoCoincide.classList.add("d-none");
            confirmarPasswordAgregar.classList.remove("is-invalid");
 
            return true;
 
        }
 
        if (password !== confirmacion) {
 
            mensajePasswordNoCoincide.classList.remove("d-none");
            confirmarPasswordAgregar.classList.add("is-invalid");
 
            return false;
 
        }
 
        mensajePasswordNoCoincide.classList.add("d-none");
        confirmarPasswordAgregar.classList.remove("is-invalid");
        confirmarPasswordAgregar.classList.add("is-valid");
 
        return true;
 
    }

    /* =========================================================
        VALIDAR SEGURIDAD DE CONTRASEÑA CON DJANGO
    ========================================================= */

    function obtenerFirmaPasswordApicultor() {

        return JSON.stringify([
            passwordAgregar
                ? passwordAgregar.value
                : "",

            usernameAgregarPassword
                ? usernameAgregarPassword.value.trim()
                : "",

            correoAgregarPassword
                ? correoAgregarPassword.value.trim().toLowerCase()
                : "",

            primerNombreAgregarPassword
                ? primerNombreAgregarPassword.value.trim()
                : "",

            primerApellidoAgregarPassword
                ? primerApellidoAgregarPassword.value.trim()
                : ""
        ]);

    }


    function invalidarPasswordApicultor() {

        if (!passwordAgregar) {
            return;
        }


        secuenciaPasswordApicultor +=
            1;


        passwordAgregar.dataset.passwordValidado =
            "0";

        passwordAgregar.dataset.passwordVerificando =
            "0";


        actualizarBotonRegistroApicultor();

    }

    async function validarSeguridadPasswordAgregar() {

        if (
            !passwordAgregar
            ||
            !formularioAgregar
            ||
            !mensajePasswordSeguridadAgregar
        ) {

            return false;
        }


        const passwordConsultado =
            passwordAgregar.value;

        const firmaConsultada =
            obtenerFirmaPasswordApicultor();


        const secuenciaActual =
            ++secuenciaPasswordApicultor;


        passwordAgregar.dataset.passwordValidado =
            "0";

        passwordAgregar.dataset.passwordVerificando =
            "1";


        actualizarBotonRegistroApicultor();


        // =====================================================
        // CAMPO VACÍO
        // =====================================================

        if (!passwordConsultado) {

            passwordAgregar.setCustomValidity(
                "La contraseña es obligatoria."
            );


            passwordAgregar.dataset.passwordValidado =
                "0";

            passwordAgregar.dataset.passwordVerificando =
                "0";


            actualizarBotonRegistroApicultor();


            return false;
        }


        // =====================================================
        // LONGITUD MÍNIMA
        // =====================================================

        if (passwordConsultado.length < 8) {

            passwordAgregar.setCustomValidity(
                "La contraseña debe tener mínimo 8 caracteres."
            );

            passwordAgregar.classList.remove(
                "is-valid"
            );

            passwordAgregar.classList.add(
                "is-invalid"
            );


            mensajePasswordSeguridadAgregar.textContent =
                "La contraseña debe tener mínimo 8 caracteres.";

            mensajePasswordSeguridadAgregar.classList.remove(
                "d-none",
                "text-success",
                "text-muted"
            );

            mensajePasswordSeguridadAgregar.classList.add(
                "text-danger"
            );

            passwordAgregar.dataset.passwordValidado =
                "0";

            passwordAgregar.dataset.passwordVerificando =
                "0";


            actualizarBotonRegistroApicultor();

            return false;
        }


        // =====================================================
        // ESTADO: VALIDANDO
        // =====================================================

        passwordAgregar.setCustomValidity("");

        passwordAgregar.classList.remove(
            "is-valid",
            "is-invalid"
        );


        mensajePasswordSeguridadAgregar.textContent =
            "Verificando seguridad de la contraseña...";

        mensajePasswordSeguridadAgregar.classList.remove(
            "d-none",
            "text-danger",
            "text-success"
        );

        mensajePasswordSeguridadAgregar.classList.add(
            "text-muted"
        );


        // =====================================================
        // DATOS PARA DJANGO
        // =====================================================

        const datos = new FormData();


        const csrf = formularioAgregar.querySelector(
            '[name="csrfmiddlewaretoken"]'
        );


        if (csrf) {

            datos.append(
                "csrfmiddlewaretoken",
                csrf.value
            );

        }


        datos.append(
            "password",
            passwordConsultado
        );


        const usernameAgregar =
            document.getElementById(
                "usernameAgregar"
            );

        const correoAgregar =
            document.getElementById(
                "correoAgregar"
            );

        const primerNombreAgregar =
            document.getElementById(
                "primerNombreAgregar"
            );

        const primerApellidoAgregar =
            document.getElementById(
                "primerApellidoAgregar"
            );


        datos.append(
            "username",
            usernameAgregar
                ? usernameAgregar.value
                : ""
        );

        datos.append(
            "correo",
            correoAgregar
                ? correoAgregar.value
                : ""
        );

        datos.append(
            "primer_nombre",
            primerNombreAgregar
                ? primerNombreAgregar.value
                : ""
        );

        datos.append(
            "primer_apellido",
            primerApellidoAgregar
                ? primerApellidoAgregar.value
                : ""
        );


        // =====================================================
        // CONSULTAR AL SERVIDOR
        // =====================================================

        try {

            const respuesta = await fetch(
                URL_VALIDAR_PASSWORD_APICULTOR,
                {
                    method: "POST",
                    body: datos,
                    credentials: "same-origin"
                }
            );


            if (!respuesta.ok) {

                throw new Error(
                    "No fue posible validar la contraseña."
                );

            }


            const resultado =
                await respuesta.json();


            // El usuario cambió la contraseña mientras
            // llegaba la respuesta del servidor.

            if (
                secuenciaActual !==
                    secuenciaPasswordApicultor
                ||
                obtenerFirmaPasswordApicultor() !==
                    firmaConsultada
                ||
                passwordAgregar.value !==
                    passwordConsultado
            ) {

                return false;
            }


            passwordAgregar.dataset.passwordVerificando =
                "0";


            // =================================================
            // CONTRASEÑA INVÁLIDA
            // =================================================

            if (!resultado.valido) {

                const mensajes = (
                    resultado.mensajes
                    &&
                    resultado.mensajes.length
                )
                    ?
                    resultado.mensajes
                    :
                    [
                        "La contraseña no cumple los requisitos de seguridad."
                    ];


                const mensajeCompleto =
                    mensajes.join(" ");


                passwordAgregar.setCustomValidity(
                    mensajeCompleto
                );


                passwordAgregar.classList.remove(
                    "is-valid"
                );

                passwordAgregar.classList.add(
                    "is-invalid"
                );


                mensajePasswordSeguridadAgregar.textContent =
                    mensajeCompleto;

                mensajePasswordSeguridadAgregar.classList.remove(
                    "d-none",
                    "text-success",
                    "text-muted"
                );

                mensajePasswordSeguridadAgregar.classList.add(
                    "text-danger"
                );

                passwordAgregar.dataset.passwordValidado =
                    "0";

                passwordAgregar.dataset.passwordVerificando =
                    "0";


                actualizarBotonRegistroApicultor();


                return false;
            }


            // =================================================
            // CONTRASEÑA VÁLIDA
            // =================================================

            passwordAgregar.setCustomValidity("");


            passwordAgregar.classList.remove(
                "is-invalid"
            );

            passwordAgregar.classList.add(
                "is-valid"
            );


            mensajePasswordSeguridadAgregar.textContent =
                (
                    resultado.mensajes
                    &&
                    resultado.mensajes.length
                )
                    ?
                    resultado.mensajes.join(" ")
                    :
                    "La contraseña cumple los requisitos de seguridad.";


            mensajePasswordSeguridadAgregar.classList.remove(
                "d-none",
                "text-danger",
                "text-muted"
            );

            mensajePasswordSeguridadAgregar.classList.add(
                "text-success"
            );


            passwordAgregar.dataset.passwordValidado =
                "1";

            passwordAgregar.dataset.passwordVerificando =
                "0";


            actualizarBotonRegistroApicultor();


            return true;


        } catch (error) {

            console.error(
                "Error validando contraseña:",
                error
            );


            const mensaje =
                (
                    "No fue posible verificar la contraseña. "
                    +
                    "Intenta nuevamente."
                );


            passwordAgregar.setCustomValidity(
                mensaje
            );


            passwordAgregar.classList.remove(
                "is-valid"
            );

            passwordAgregar.classList.add(
                "is-invalid"
            );


            mensajePasswordSeguridadAgregar.textContent =
                mensaje;

            mensajePasswordSeguridadAgregar.classList.remove(
                "d-none",
                "text-success",
                "text-muted"
            );

            mensajePasswordSeguridadAgregar.classList.add(
                "text-danger"
            );

            passwordAgregar.dataset.passwordValidado =
                "0";

            passwordAgregar.dataset.passwordVerificando =
                "0";


            actualizarBotonRegistroApicultor();


            return false;
        }

    }

    function programarValidacionPasswordApicultor() {

        clearTimeout(
            temporizadorPasswordApicultor
        );


        if (
            !passwordAgregar ||
            !passwordAgregar.value
        ) {

            invalidarPasswordApicultor();

            return;

        }


        if (
            passwordAgregar.value.length < 8
        ) {

            validarSeguridadPasswordAgregar();

            return;

        }


        secuenciaPasswordApicultor +=
            1;


        passwordAgregar.dataset.passwordValidado =
            "0";

        passwordAgregar.dataset.passwordVerificando =
            "1";


        if (mensajePasswordSeguridadAgregar) {

            mensajePasswordSeguridadAgregar.textContent =
                "Verificando seguridad de la contraseña...";

            mensajePasswordSeguridadAgregar.classList.remove(
                "d-none",
                "text-danger",
                "text-success"
            );

            mensajePasswordSeguridadAgregar.classList.add(
                "text-muted"
            );

        }


        actualizarBotonRegistroApicultor();


        temporizadorPasswordApicultor =
            setTimeout(
                async function () {

                    await validarSeguridadPasswordAgregar();

                    validarContrasenas();

                    actualizarBotonRegistroApicultor();

                },
                400
            );

    }
 
    if (passwordAgregar) {

        passwordAgregar.addEventListener(
            "input",
            function () {

                passwordAgregar.setCustomValidity("");

                passwordAgregar.classList.remove(
                    "is-valid",
                    "is-invalid"
                );


                programarValidacionPasswordApicultor();


                validarContrasenas();


                actualizarBotonRegistroApicultor();

            }
        );


        passwordAgregar.addEventListener(
            "blur",
            async function () {

                clearTimeout(
                    temporizadorPasswordApicultor
                );


                if (passwordAgregar.value) {

                    await validarSeguridadPasswordAgregar();

                    validarContrasenas();

                    actualizarBotonRegistroApicultor();

                }

            }
        );

    }


    if (confirmarPasswordAgregar) {

        confirmarPasswordAgregar.addEventListener(
            "input",
            function () {

                validarContrasenas();

                actualizarBotonRegistroApicultor();

            }
        );

    }
 
    [
        usernameAgregarPassword,
        correoAgregarPassword,
        primerNombreAgregarPassword,
        primerApellidoAgregarPassword
    ]
        .filter(Boolean)
        .forEach(
            function (campo) {

                campo.addEventListener(
                    "input",
                    function () {

                        if (
                            passwordAgregar &&
                            passwordAgregar.value
                        ) {

                            programarValidacionPasswordApicultor();

                        }
                        else {

                            actualizarBotonRegistroApicultor();

                        }

                    }
                );

            }
        );


    if (formularioAgregar) {

        formularioAgregar.addEventListener(
            "input",
            actualizarBotonRegistroApicultor
        );

    }
    
    /* =========================================================
        ENVÍO DEL FORMULARIO
    ========================================================= */

    let permitirSiguienteEnvioAgregar =
        false;


    if (formularioAgregar) {

        formularioAgregar.addEventListener(
            "submit",
            async function (evento) {


                // =================================================
                // SEGUNDO ENVÍO
                // =================================================
                //
                // Este segundo envío ocurre únicamente después
                // de que Django confirmó que la contraseña es válida.
                // =================================================

                if (permitirSiguienteEnvioAgregar) {

                    permitirSiguienteEnvioAgregar =
                        false;


                    if (botonGuardarApicultor) {

                        botonGuardarApicultor.disabled =
                            true;

                        botonGuardarApicultor.innerHTML = `
                            <span
                                class="spinner-border spinner-border-sm me-2"
                                aria-hidden="true"
                            ></span>
                            Registrando...
                        `;

                    }


                    return;
                }


                // Por ahora NO dejamos enviar.

                evento.preventDefault();


                // =================================================
                // CONTRASEÑAS COINCIDEN
                // =================================================

                const contrasenasValidas =
                    validarContrasenas();


                if (!contrasenasValidas) {

                    confirmarPasswordAgregar.focus();

                    return;
                }


                // =================================================
                // VALIDACIONES HTML
                // =================================================

                if (
                    !formularioAgregar.checkValidity()
                ) {

                    formularioAgregar.classList.add(
                        "was-validated"
                    );

                    formularioAgregar.reportValidity();

                    return;
                }


                // =================================================
                // VALIDACIÓN REAL DE DJANGO
                // =================================================

                const passwordSeguro =
                    await validarSeguridadPasswordAgregar();


                if (!passwordSeguro) {

                    passwordAgregar.focus();

                    passwordAgregar.reportValidity();

                    return;
                }


                // =================================================
                // REVISAR DE NUEVO COINCIDENCIA
                // =================================================

                if (!validarContrasenas()) {

                    confirmarPasswordAgregar.focus();

                    return;
                }


                // =================================================
                // TODO CORRECTO
                // =================================================
                //
                // Disparamos nuevamente el submit. En esta segunda
                // ejecución se permitirá continuar al servidor.
                // =================================================

                permitirSiguienteEnvioAgregar =
                    true;


                formularioAgregar.requestSubmit();

            }
        );

    }
 
 
    /* =========================================================
    LIMPIAR FORMULARIO AL CERRAR EL MODAL
    ========================================================= */
 
    if (modalAgregarElemento) {
 
        modalAgregarElemento.addEventListener(
            "hidden.bs.modal",
            function () {
 
                if (formularioAgregar) {
 
                    formularioAgregar.reset();
 
                    formularioAgregar.classList.remove(
                        "was-validated"
                    );
 
                }
 
                limpiarVistaPreviaAgregar();
 
                if (mensajePasswordNoCoincide) {
 
                    mensajePasswordNoCoincide.classList.add(
                        "d-none"
                    );
 
                }

                if (passwordAgregar) {

                    passwordAgregar.setCustomValidity("");

                    passwordAgregar.classList.remove(
                        "is-valid",
                        "is-invalid"
                    );


                    passwordAgregar.dataset.passwordValidado =
                        "0";

                    passwordAgregar.dataset.passwordVerificando =
                        "0";

                }


                if (mensajePasswordSeguridadAgregar) {

                    mensajePasswordSeguridadAgregar.textContent =
                        "";

                    mensajePasswordSeguridadAgregar.classList.add(
                        "d-none"
                    );

                    mensajePasswordSeguridadAgregar.classList.remove(
                        "text-danger",
                        "text-success",
                        "text-muted"
                    );

                }


                permitirSiguienteEnvioAgregar =
                    false;
 
                if (confirmarPasswordAgregar) {
 
                    confirmarPasswordAgregar.classList.remove(
                        "is-invalid",
                        "is-valid"
                    );
 
                }
 
                if (botonGuardarApicultor) {
 
                    botonGuardarApicultor.disabled = true;
 
                    botonGuardarApicultor.innerHTML = `
                        <i class="bi bi-person-check-fill me-2"></i>
                        Registrar apicultor
                    `;
 
                }
 
                document
                    .querySelectorAll(".btn-mostrar-password")
                    .forEach(function (boton) {
 
                        const idInput = boton.dataset.passwordTarget;
                        const input = document.getElementById(idInput);
                        const icono = boton.querySelector("i");
 
                        if (input) {
                            input.type = "password";
                        }
 
                        if (icono) {
 
                            icono.classList.remove(
                                "bi-eye-slash-fill"
                            );
 
                            icono.classList.add(
                                "bi-eye-fill"
                            );
 
                        }
 
                    });
 
            }
        );
 
    }
 
 
    /* =========================================================
    TOOLTIPS DE BOOTSTRAP
    ========================================================= */
 
    if (typeof bootstrap !== "undefined") {
 
        const elementosTooltip = document.querySelectorAll(
            "[title]"
        );
 
        elementosTooltip.forEach(function (elemento) {
 
            new bootstrap.Tooltip(elemento);
 
        });
 
    }
 
});
 
/* =========================================================
   VISTA PREVIA DE LA FOTO DEL APICULTOR
========================================================= */
 
const inputFotoAgregar = document.getElementById(
    "fotoperfilAgregar"
);
 
const imagenPreviewAgregar = document.getElementById(
    "imagenPreviewAgregar"
);
 
const iconoPreviewAgregar = document.getElementById(
    "iconoPreviewAgregar"
);
 
const botonQuitarFotoAgregar = document.getElementById(
    "btnQuitarFotoAgregar"
);
 
 
function limpiarFotoAgregar() {
 
    if (inputFotoAgregar) {
        inputFotoAgregar.value = "";
    }
 
    if (imagenPreviewAgregar) {
        imagenPreviewAgregar.removeAttribute("src");
        imagenPreviewAgregar.classList.add("d-none");
    }
 
    if (iconoPreviewAgregar) {
        iconoPreviewAgregar.classList.remove("d-none");
    }
 
    if (botonQuitarFotoAgregar) {
        botonQuitarFotoAgregar.classList.add("d-none");
    }
 
}
 
 
if (inputFotoAgregar) {
 
    inputFotoAgregar.addEventListener("change", function () {
 
        const archivo = this.files && this.files[0];
 
        if (!archivo) {
            limpiarFotoAgregar();
            return;
        }
 
        const tiposPermitidos = [
            "image/jpeg",
            "image/png",
            "image/webp"
        ];
 
        if (!tiposPermitidos.includes(archivo.type)) {
 
            alert(
                "Selecciona una imagen en formato JPG, PNG o WEBP."
            );
 
            limpiarFotoAgregar();
            return;
        }
 
        const tamanoMaximo = 5 * 1024 * 1024;
 
        if (archivo.size > tamanoMaximo) {
 
            alert(
                "La imagen no puede superar los 5 MB."
            );
 
            limpiarFotoAgregar();
            return;
        }
 
        const lector = new FileReader();
 
        lector.onload = function (evento) {
 
            if (!imagenPreviewAgregar) {
                return;
            }
 
            imagenPreviewAgregar.src = evento.target.result;
            imagenPreviewAgregar.classList.remove("d-none");
 
            if (iconoPreviewAgregar) {
                iconoPreviewAgregar.classList.add("d-none");
            }
 
            if (botonQuitarFotoAgregar) {
                botonQuitarFotoAgregar.classList.remove("d-none");
            }
 
        };
 
        lector.onerror = function () {
 
            alert(
                "No fue posible cargar la vista previa de la imagen."
            );
 
            limpiarFotoAgregar();
 
        };
 
        lector.readAsDataURL(archivo);
 
    });
 
}
 
 
if (botonQuitarFotoAgregar) {
 
    botonQuitarFotoAgregar.addEventListener(
        "click",
        function () {
            limpiarFotoAgregar();
        }
    );
 
}
 
 
/*MODAL DETALLE APICULTOR*/
 
document.addEventListener("DOMContentLoaded", function () {
 
    const modalDetalle = document.getElementById(
        "modalDetalleApicultor"
    );
 
    if (!modalDetalle) {
        return;
    }
 
    modalDetalle.addEventListener(
        "show.bs.modal",
        function (evento) {
 
            const boton = evento.relatedTarget;
 
            if (!boton) {
                return;
            }
 
            /* ===============================================
            DATOS RECIBIDOS DESDE EL BOTÓN DE LA TABLA
            =============================================== */
 
            const id = boton.dataset.id || "—";
            const urlPerfil = boton.dataset.perfilUrl || "#";
            const botonPerfilCompleto = document.getElementById(
                "btnPerfilCompletoApicultor"
            );
 
            if (botonPerfilCompleto) {
                botonPerfilCompleto.href = urlPerfil;
            }
            cargarApiariosDelApicultor(id);
            const nombre = boton.dataset.nombre || "Sin nombre";
            const nombres = boton.dataset.nombres || "Sin registrar";
            const apellidos = boton.dataset.apellidos || "Sin registrar";
            const username = boton.dataset.username || "Sin usuario";
            const identificacion =
                boton.dataset.identificacion || "Sin registrar";
 
            const correo = boton.dataset.correo || "";
            const telefono = boton.dataset.telefono || "";
            const zona = boton.dataset.zona || "Sin registrar";
            const experiencia = boton.dataset.experiencia || "";
            const rol = boton.dataset.rol || "Apicultor";
            const apiarios = Number(boton.dataset.apiarios || 0);
            const activo = boton.dataset.activo || "No";
            const foto = boton.dataset.foto || "";
 
 
            /* ===============================================
            INFORMACIÓN PRINCIPAL
            =============================================== */
 
            asignarTexto(
                "detalleIdApicultor",
                id
            );
 
            asignarTexto(
                "detalleNombreApicultor",
                nombre
            );
 
            asignarTexto(
                "detalleNombresApicultor",
                nombres
            );
 
            asignarTexto(
                "detalleApellidosApicultor",
                apellidos
            );
 
            asignarTexto(
                "detalleUsernameApicultor",
                username
            );
 
            asignarTexto(
                "detalleIdentificacionApicultor",
                identificacion
            );
 
            asignarTexto(
                "detalleRolApicultor",
                rol
            );
 
            asignarTexto(
                "detalleZonaApicultor",
                zona
            );
 
 
            /* ===============================================
            EXPERIENCIA
            =============================================== */
 
            let textoExperiencia = "Sin registrar";
 
            if (experiencia !== "") {
 
                const cantidadExperiencia = Number(experiencia);
 
                textoExperiencia =
                    `${cantidadExperiencia} ${
                        cantidadExperiencia === 1
                            ? "año"
                            : "años"
                    }`;
 
            }
 
            asignarTexto(
                "detalleExperienciaApicultor",
                textoExperiencia
            );
 
 
            /* ===============================================
            APIARIOS
            =============================================== */
 
            asignarTexto(
                "detalleCantidadApiarios",
                apiarios
            );
 
            asignarTexto(
                "detalleTextoApiarios",
                apiarios === 1
                    ? "Apiario"
                    : "Apiarios"
            );
 
 
            /* ===============================================
            CORREO Y TELÉFONO
            =============================================== */
 
            configurarEnlace(
                "detalleCorreoApicultor",
                correo,
                "mailto:",
                "Sin registrar"
            );
 
            configurarEnlace(
                "detalleTelefonoApicultor",
                telefono,
                "tel:",
                "Sin registrar"
            );
 
 
            /* ===============================================
            ESTADO DEL USUARIO
            =============================================== */
 
            const elementoEstado = document.getElementById(
                "detalleEstadoApicultor"
            );
 
            const indicadorEstado = document.getElementById(
                "detalleIndicadorEstado"
            );
 
            const estaActivo = activo.toLowerCase() === "sí";
 
            if (elementoEstado) {
 
                elementoEstado.textContent = estaActivo
                    ? "Usuario activo"
                    : "Usuario inactivo";
 
                elementoEstado.classList.remove(
                    "estado-detalle-activo",
                    "estado-detalle-inactivo"
                );
 
                elementoEstado.classList.add(
                    estaActivo
                        ? "estado-detalle-activo"
                        : "estado-detalle-inactivo"
                );
 
            }
 
            if (indicadorEstado) {
 
                indicadorEstado.classList.remove(
                    "indicador-detalle-activo",
                    "indicador-detalle-inactivo"
                );
 
                indicadorEstado.classList.add(
                    estaActivo
                        ? "indicador-detalle-activo"
                        : "indicador-detalle-inactivo"
                );
 
                indicadorEstado.title = estaActivo
                    ? "Usuario activo"
                    : "Usuario inactivo";
 
            }
 
 
            /* ===============================================
            FOTO
            =============================================== */
 
            const imagenFoto = document.getElementById(
                "detalleFotoApicultor"
            );
 
            const fotoSinImagen = document.getElementById(
                "detalleFotoSinImagen"
            );
 
            if (foto && imagenFoto) {
 
                imagenFoto.src = foto;
                imagenFoto.alt = `Foto de ${nombre}`;
                imagenFoto.classList.remove("d-none");
 
                if (fotoSinImagen) {
                    fotoSinImagen.classList.add("d-none");
                }
 
            } else {
 
                if (imagenFoto) {
                    imagenFoto.removeAttribute("src");
                    imagenFoto.classList.add("d-none");
                }
 
                if (fotoSinImagen) {
                    fotoSinImagen.classList.remove("d-none");
                }
 
            }
 
        }
    );
 
 
    /* =====================================================
    FUNCIÓN PARA ASIGNAR TEXTO
    ====================================================== */
 
    function asignarTexto(idElemento, valor) {
 
        const elemento = document.getElementById(idElemento);
 
        if (elemento) {
            elemento.textContent = valor;
        }
 
    }
 
 
    /* =====================================================
    FUNCIÓN PARA CONFIGURAR ENLACES
    ====================================================== */
 
    function configurarEnlace(
        idElemento,
        valor,
        prefijo,
        textoVacio
    ) {
 
        const elemento = document.getElementById(idElemento);
 
        if (!elemento) {
            return;
        }
 
        if (valor) {
 
            elemento.textContent = valor;
            elemento.href = `${prefijo}${valor}`;
            elemento.classList.remove("enlace-dato-vacio");
 
        } else {
 
            elemento.textContent = textoVacio;
            elemento.href = "#";
            elemento.classList.add("enlace-dato-vacio");
 
        }
 
    }
 
    /* =========================================================
    CARGAR APIARIOS EN EL MODAL DE DETALLE
    ========================================================= */
 
    function cargarApiariosDelApicultor(idApicultor) {
 
        const listaApiarios = document.getElementById(
            "listaApiariosDetalle"
        );
 
        const contadorPanel = document.getElementById(
            "contadorPanelApiarios"
        );
 
        const botonApiarios = document.getElementById(
            "btnMostrarApiariosDetalle"
        );
 
        const panelApiarios = document.getElementById(
            "panelApiariosDetalle"
        );
 
        const templateApiarios = document.getElementById(
            `templateApiariosApicultor${idApicultor}`
        );
 
        if (!listaApiarios) {
            return;
        }
 
        listaApiarios.innerHTML = "";
 
        if (templateApiarios) {
 
            const contenido = templateApiarios.content.cloneNode(true);
 
            listaApiarios.appendChild(contenido);
 
        } else {
 
            listaApiarios.innerHTML = `
                <div class="estado-sin-apiarios-detalle">
                    <div class="icono-sin-apiarios-detalle">
                        <i class="bi bi-inboxes-fill"></i>
                    </div>
 
                    <h6>No fue posible cargar los apiarios</h6>
 
                    <p>
                        No se encontró la información relacionada con
                        este apicultor.
                    </p>
                </div>
            `;
 
        }
 
        const cantidad = listaApiarios.querySelectorAll(
            ".item-apiario-detalle"
        ).length;
 
        if (contadorPanel) {
            contadorPanel.textContent = cantidad;
        }
 
        /*
        Cerrar la lista cada vez que se abra el detalle
        de otro apicultor.
        */
        if (panelApiarios) {
 
            const instanciaCollapse =
                bootstrap.Collapse.getOrCreateInstance(
                    panelApiarios,
                    {
                        toggle: false
                    }
                );
 
            instanciaCollapse.hide();
 
        }
 
        if (botonApiarios) {
            botonApiarios.setAttribute(
                "aria-expanded",
                "false"
            );
        }
 
    }
 
});
 
/*MODAL DE EDITAR APICULTOR */
document.addEventListener("DOMContentLoaded", function () {
 
    const modalEditar = document.getElementById(
        "modalEditarApicultor"
    );
 
    const formularioEditar = document.getElementById(
        "formEditarApicultor"
    );
 
    if (!modalEditar || !formularioEditar) {
        return;
    }
 
 
    /* =========================================================
       CAMPOS
    ========================================================= */
 
    const nombresEditar = document.getElementById(
        "nombresEditar"
    );
 
    const apellidosEditar = document.getElementById(
        "apellidosEditar"
    );
 
    const identificacionEditar = document.getElementById(
        "identificacionEditar"
    );
 
    const telefonoEditar = document.getElementById(
        "telefonoEditar"
    );
 
    const correoEditar = document.getElementById(
        "correoEditar"
    );
 
    const zonaTrabajoEditar = document.getElementById(
        "zonaTrabajoEditar"
    );
 
    const experienciaEditar = document.getElementById(
        "experienciaEditar"
    );
 
    const usernameEditar = document.getElementById(
        "usernameEditar"
    );
 
    const passwordEditar = document.getElementById(
        "passwordEditar"
    );
 
    const confirmarPasswordEditar = document.getElementById(
        "confirmarPasswordEditar"
    );
 
    const mensajePassword = document.getElementById(
        "mensajePasswordEditarNoCoincide"
    );

    const mensajePasswordSeguridadEditar =
        document.getElementById(
            "mensajePasswordSeguridadEditar"
        );
 
    const usuarioActivoEditar = document.getElementById(
        "usuarioActivoEditar"
    );
 
    const textoEstadoUsuario = document.getElementById(
        "textoEstadoUsuarioEditar"
    );
 
    const inputFotoEditar = document.getElementById(
        "fotoperfilEditar"
    );
 
    const imagenPreviewEditar = document.getElementById(
        "imagenPreviewEditar"
    );
 
    const iconoPreviewEditar = document.getElementById(
        "iconoPreviewEditar"
    );
 
    const botonQuitarFotoEditar = document.getElementById(
        "btnQuitarFotoEditar"
    );
 
    const eliminarFotoEditar = document.getElementById(
        "eliminarFotoEditar"
    );
 
    const botonGuardar = document.getElementById(
        "btnGuardarEdicionApicultor"
    );
 
    let fotoOriginalEditar = "";

    let temporizadorPasswordEditar =
        null;


    let secuenciaPasswordEditar =
        0;


    let permitirSiguienteEnvioEditar =
        false;


    if (passwordEditar) {

        passwordEditar.dataset.passwordValidado =
            "0";

        passwordEditar.dataset.passwordVerificando =
            "0";

    }
 
 
    /* =========================================================
       ABRIR MODAL Y CARGAR DATOS
    ========================================================= */
 
    modalEditar.addEventListener(
        "show.bs.modal",
        function (evento) {
 
            const boton = evento.relatedTarget;
 
            if (!boton) {
                return;
            }
 
            formularioEditar.action = boton.dataset.url || "";
 
            asignarValor(
                nombresEditar,
                boton.dataset.nombres
            );
 
            asignarValor(
                apellidosEditar,
                boton.dataset.apellidos
            );
 
            asignarValor(
                identificacionEditar,
                boton.dataset.identificacion
            );
 
            asignarValor(
                telefonoEditar,
                boton.dataset.telefono
            );
 
            asignarValor(
                correoEditar,
                boton.dataset.correo
            );
 
            asignarValor(
                zonaTrabajoEditar,
                boton.dataset.zona
            );
 
            asignarValor(
                experienciaEditar,
                boton.dataset.experiencia
            );
 
            asignarValor(
                usernameEditar,
                boton.dataset.username
            );
 
            if (passwordEditar) {
                passwordEditar.value = "";
            }
 
            if (confirmarPasswordEditar) {
                confirmarPasswordEditar.value = "";
            }
 
            if (mensajePassword) {
                mensajePassword.classList.add("d-none");
            }
 
            if (eliminarFotoEditar) {
                eliminarFotoEditar.value = "0";
            }
 
            fotoOriginalEditar = boton.dataset.foto || "";
 
            mostrarFotoEditar(
                fotoOriginalEditar
            );
 
            const usuarioActivo =
                boton.dataset.activo === "1";
 
            if (usuarioActivoEditar) {
                usuarioActivoEditar.checked = usuarioActivo;
            }


            /* Limpiar estados de validación del apicultor anterior */
            [
                nombresEditar,
                apellidosEditar,
                identificacionEditar,
                telefonoEditar,
                correoEditar,
                usernameEditar
            ]
                .filter(Boolean)
                .forEach(
                    function (campo) {

                        campo.setCustomValidity("");

                        campo.classList.remove(
                            "is-valid",
                            "is-invalid"
                        );

                        campo.dataset.duplicado =
                            "0";

                        campo.dataset.verificando =
                            "0";

                    }
                );


            if (passwordEditar) {

                passwordEditar.dataset.passwordValidado =
                    "0";

                passwordEditar.dataset.passwordVerificando =
                    "0";

                passwordEditar.setCustomValidity("");

                passwordEditar.classList.remove(
                    "is-valid",
                    "is-invalid"
                );

            }


            if (confirmarPasswordEditar) {

                confirmarPasswordEditar.setCustomValidity("");

                confirmarPasswordEditar.classList.remove(
                    "is-valid",
                    "is-invalid"
                );

            }


            ocultarMensajeSeguridadEditar();


            permitirSiguienteEnvioEditar =
                false;


            actualizarTextoEstado();

            actualizarBotonEdicionApicultor();
 
        }
    );
 
 
    /* =========================================================
       ESTADO ACTIVO O INACTIVO
    ========================================================= */
 
    function actualizarTextoEstado() {
 
        if (!usuarioActivoEditar || !textoEstadoUsuario) {
            return;
        }
 
        textoEstadoUsuario.textContent =
            usuarioActivoEditar.checked
                ? "Usuario activo"
                : "Usuario inactivo";
 
        textoEstadoUsuario.classList.toggle(
            "texto-usuario-inactivo",
            !usuarioActivoEditar.checked
        );
 
    }
 
 
    if (usuarioActivoEditar) {
 
        usuarioActivoEditar.addEventListener(
            "change",
            actualizarTextoEstado
        );
 
    }
 
 
    /* =========================================================
       VISTA PREVIA DE FOTO
    ========================================================= */
 
    function mostrarFotoEditar(urlFoto) {
 
        if (urlFoto) {
 
            if (imagenPreviewEditar) {
 
                imagenPreviewEditar.src = urlFoto;
                imagenPreviewEditar.classList.remove("d-none");
 
            }
 
            if (iconoPreviewEditar) {
                iconoPreviewEditar.classList.add("d-none");
            }
 
            if (botonQuitarFotoEditar) {
                botonQuitarFotoEditar.classList.remove("d-none");
            }
 
        } else {
 
            if (imagenPreviewEditar) {
 
                imagenPreviewEditar.removeAttribute("src");
                imagenPreviewEditar.classList.add("d-none");
 
            }
 
            if (iconoPreviewEditar) {
                iconoPreviewEditar.classList.remove("d-none");
            }
 
            if (botonQuitarFotoEditar) {
                botonQuitarFotoEditar.classList.add("d-none");
            }
 
        }
 
    }
 
 
    if (inputFotoEditar) {
 
        inputFotoEditar.addEventListener(
            "change",
            function () {
 
                const archivo = inputFotoEditar.files[0];
 
                if (!archivo) {
                    mostrarFotoEditar(fotoOriginalEditar);
                    return;
                }
 
                const tiposPermitidos = [
                    "image/jpeg",
                    "image/png",
                    "image/webp"
                ];
 
                if (!tiposPermitidos.includes(archivo.type)) {
 
                    alert(
                        "La imagen debe estar en formato JPG, PNG o WEBP."
                    );
 
                    inputFotoEditar.value = "";
 
                    mostrarFotoEditar(
                        fotoOriginalEditar
                    );
 
                    return;
                }
 
                const tamanoMaximo = 5 * 1024 * 1024;
 
                if (archivo.size > tamanoMaximo) {
 
                    alert(
                        "La imagen no puede superar los 5 MB."
                    );
 
                    inputFotoEditar.value = "";
 
                    mostrarFotoEditar(
                        fotoOriginalEditar
                    );
 
                    return;
                }
 
                const lector = new FileReader();
 
                lector.onload = function (eventoLectura) {
 
                    mostrarFotoEditar(
                        eventoLectura.target.result
                    );
 
                    if (eliminarFotoEditar) {
                        eliminarFotoEditar.value = "0";
                    }
 
                };
 
                lector.onerror = function () {
 
                    alert(
                        "No fue posible cargar la vista previa."
                    );
 
                    inputFotoEditar.value = "";
 
                    mostrarFotoEditar(
                        fotoOriginalEditar
                    );
 
                };
 
                lector.readAsDataURL(archivo);
 
            }
        );
 
    }
 
 
    /* =========================================================
       QUITAR FOTO
    ========================================================= */
 
    if (botonQuitarFotoEditar) {
 
        botonQuitarFotoEditar.addEventListener(
            "click",
            function () {
 
                if (inputFotoEditar) {
                    inputFotoEditar.value = "";
                }
 
                if (eliminarFotoEditar) {
                    eliminarFotoEditar.value = "1";
                }
 
                mostrarFotoEditar("");
 
            }
        );
 
    }
 
 
    /* =========================================================
    VALIDAR CONTRASEÑA EN EDICIÓN
    ========================================================= */

    function hayCambioPasswordEditar() {

        if (
            !passwordEditar ||
            !confirmarPasswordEditar
        ) {

            return false;

        }


        return Boolean(
            passwordEditar.value ||
            confirmarPasswordEditar.value
        );

    }


    function obtenerFirmaPasswordEditar() {

        return JSON.stringify([
            passwordEditar
                ? passwordEditar.value
                : "",

            usernameEditar
                ? usernameEditar.value.trim()
                : "",

            correoEditar
                ? correoEditar.value.trim().toLowerCase()
                : "",

            nombresEditar
                ? nombresEditar.value.trim()
                : "",

            apellidosEditar
                ? apellidosEditar.value.trim()
                : ""
        ]);

    }


    function actualizarBotonEdicionApicultor() {

        if (
            !formularioEditar ||
            !botonGuardar
        ) {

            return;

        }


        const hayDuplicado =
            formularioEditar.querySelector(
                '[data-duplicado="1"]'
            );


        const hayVerificando =
            formularioEditar.querySelector(
                '[data-verificando="1"]'
            );


        const cambioPassword =
            hayCambioPasswordEditar();


        const passwordVerificando =
            Boolean(
                passwordEditar &&
                passwordEditar.dataset.passwordVerificando === "1"
            );


        const passwordValidado =
            Boolean(
                passwordEditar &&
                passwordEditar.dataset.passwordValidado === "1"
            );


        const passwordsCoinciden =
            Boolean(
                passwordEditar &&
                confirmarPasswordEditar &&
                passwordEditar.value &&
                confirmarPasswordEditar.value &&
                passwordEditar.value ===
                    confirmarPasswordEditar.value
            );


        const passwordCorrecto =
            (
                !cambioPassword
                ||
                (
                    !passwordVerificando &&
                    passwordValidado &&
                    passwordsCoinciden
                )
            );


        const formularioValido =
            formularioEditar.checkValidity();


        botonGuardar.disabled =
            !(
                formularioValido &&
                !hayDuplicado &&
                !hayVerificando &&
                passwordCorrecto
            );

    }


    function invalidarPasswordEditar() {

        if (!passwordEditar) {
            return;
        }


        secuenciaPasswordEditar +=
            1;


        passwordEditar.dataset.passwordValidado =
            "0";

        passwordEditar.dataset.passwordVerificando =
            "0";


        actualizarBotonEdicionApicultor();

    }


    function ocultarMensajeSeguridadEditar() {

        if (!mensajePasswordSeguridadEditar) {
            return;
        }


        mensajePasswordSeguridadEditar.textContent =
            "";

        mensajePasswordSeguridadEditar.classList.add(
            "d-none"
        );

        mensajePasswordSeguridadEditar.classList.remove(
            "text-danger",
            "text-success",
            "text-muted"
        );

    }


    function mostrarMensajeSeguridadEditar(
        estado,
        mensaje
    ) {

        if (!mensajePasswordSeguridadEditar) {
            return;
        }


        mensajePasswordSeguridadEditar.textContent =
            mensaje;


        mensajePasswordSeguridadEditar.classList.remove(
            "d-none",
            "text-danger",
            "text-success",
            "text-muted"
        );


        if (estado === "error") {

            mensajePasswordSeguridadEditar.classList.add(
                "text-danger"
            );

            return;

        }


        if (estado === "valido") {

            mensajePasswordSeguridadEditar.classList.add(
                "text-success"
            );

            return;

        }


        mensajePasswordSeguridadEditar.classList.add(
            "text-muted"
        );

    }


    function validarPasswordEditar() {

        if (
            !passwordEditar ||
            !confirmarPasswordEditar
        ) {

            return true;

        }


        const password =
            passwordEditar.value;

        const confirmacion =
            confirmarPasswordEditar.value;


        confirmarPasswordEditar.setCustomValidity("");

        confirmarPasswordEditar.classList.remove(
            "is-invalid",
            "is-valid"
        );


        // =====================================================
        // AMBOS VACÍOS = CONSERVAR CONTRASEÑA ACTUAL
        // =====================================================

        if (
            !password &&
            !confirmacion
        ) {

            passwordEditar.setCustomValidity("");

            passwordEditar.classList.remove(
                "is-valid",
                "is-invalid"
            );


            if (mensajePassword) {

                mensajePassword.classList.add(
                    "d-none"
                );

            }


            ocultarMensajeSeguridadEditar();


            return true;

        }


        // =====================================================
        // CONFIRMACIÓN SIN CONTRASEÑA
        // =====================================================

        if (!password) {

            passwordEditar.setCustomValidity(
                "Ingresa la nueva contraseña."
            );

            passwordEditar.classList.remove(
                "is-valid"
            );

            passwordEditar.classList.add(
                "is-invalid"
            );


            return false;

        }


        // =====================================================
        // MÍNIMO 8 CARACTERES
        // =====================================================

        if (password.length < 8) {

            passwordEditar.setCustomValidity(
                "La contraseña debe tener mínimo 8 caracteres."
            );

            passwordEditar.classList.remove(
                "is-valid"
            );

            passwordEditar.classList.add(
                "is-invalid"
            );


            mostrarMensajeSeguridadEditar(
                "error",
                "La contraseña debe tener mínimo 8 caracteres."
            );


            return false;

        }


        // =====================================================
        // COINCIDENCIA
        // =====================================================

        if (
            !confirmacion ||
            password !== confirmacion
        ) {

            confirmarPasswordEditar.setCustomValidity(
                "Las contraseñas no coinciden."
            );

            confirmarPasswordEditar.classList.add(
                "is-invalid"
            );


            if (mensajePassword) {

                mensajePassword.classList.remove(
                    "d-none"
                );

            }


            return false;

        }


        confirmarPasswordEditar.classList.add(
            "is-valid"
        );


        if (mensajePassword) {

            mensajePassword.classList.add(
                "d-none"
            );

        }


        return true;

    }


    /* =========================================================
    VALIDACIÓN REAL CON DJANGO
    ========================================================= */

    async function validarSeguridadPasswordEditar() {

        if (
            !passwordEditar ||
            !formularioEditar
        ) {

            return false;

        }


        const passwordConsultado =
            passwordEditar.value;


        // Contraseña vacía = no se desea cambiar.
        if (!passwordConsultado) {

            invalidarPasswordEditar();

            ocultarMensajeSeguridadEditar();

            passwordEditar.setCustomValidity("");


            return true;

        }


        if (
            passwordConsultado.length < 8
        ) {

            passwordEditar.dataset.passwordValidado =
                "0";

            passwordEditar.dataset.passwordVerificando =
                "0";


            passwordEditar.setCustomValidity(
                "La contraseña debe tener mínimo 8 caracteres."
            );


            mostrarMensajeSeguridadEditar(
                "error",
                "La contraseña debe tener mínimo 8 caracteres."
            );


            actualizarBotonEdicionApicultor();


            return false;

        }


        const firmaConsultada =
            obtenerFirmaPasswordEditar();


        const secuenciaActual =
            ++secuenciaPasswordEditar;


        passwordEditar.dataset.passwordValidado =
            "0";

        passwordEditar.dataset.passwordVerificando =
            "1";


        passwordEditar.setCustomValidity("");


        passwordEditar.classList.remove(
            "is-valid",
            "is-invalid"
        );


        mostrarMensajeSeguridadEditar(
            "verificando",
            "Verificando seguridad de la contraseña..."
        );


        actualizarBotonEdicionApicultor();


        const datos =
            new FormData();


        const csrf =
            formularioEditar.querySelector(
                '[name="csrfmiddlewaretoken"]'
            );


        if (csrf) {

            datos.append(
                "csrfmiddlewaretoken",
                csrf.value
            );

        }


        datos.append(
            "password",
            passwordConsultado
        );


        datos.append(
            "username",
            usernameEditar
                ? usernameEditar.value
                : ""
        );


        datos.append(
            "correo",
            correoEditar
                ? correoEditar.value
                : ""
        );


        /*
        * El endpoint recibe estos nombres porque también
        * lo utiliza el formulario de creación.
        *
        * En edición enviamos los nombres completos.
        */
        datos.append(
            "primer_nombre",
            nombresEditar
                ? nombresEditar.value
                : ""
        );


        datos.append(
            "primer_apellido",
            apellidosEditar
                ? apellidosEditar.value
                : ""
        );


        try {

            const respuesta =
                await fetch(
                    URL_VALIDAR_PASSWORD_APICULTOR,
                    {
                        method: "POST",
                        body: datos,
                        credentials: "same-origin"
                    }
                );


            if (!respuesta.ok) {

                throw new Error(
                    "No fue posible validar la contraseña."
                );

            }


            const resultado =
                await respuesta.json();


            // Ignorar respuestas anteriores.
            if (
                secuenciaActual !==
                    secuenciaPasswordEditar
                ||
                obtenerFirmaPasswordEditar() !==
                    firmaConsultada
                ||
                passwordEditar.value !==
                    passwordConsultado
            ) {

                return false;

            }


            passwordEditar.dataset.passwordVerificando =
                "0";


            // =================================================
            // INVÁLIDA
            // =================================================

            if (!resultado.valido) {

                const mensajes =
                    (
                        resultado.mensajes &&
                        resultado.mensajes.length
                    )
                        ?
                        resultado.mensajes
                        :
                        [
                            "La contraseña no cumple los requisitos de seguridad."
                        ];


                const mensajeCompleto =
                    mensajes.join(" ");


                passwordEditar.dataset.passwordValidado =
                    "0";


                passwordEditar.setCustomValidity(
                    mensajeCompleto
                );


                passwordEditar.classList.remove(
                    "is-valid"
                );

                passwordEditar.classList.add(
                    "is-invalid"
                );


                mostrarMensajeSeguridadEditar(
                    "error",
                    mensajeCompleto
                );


                actualizarBotonEdicionApicultor();


                return false;

            }


            // =================================================
            // VÁLIDA
            // =================================================

            passwordEditar.dataset.passwordValidado =
                "1";

            passwordEditar.dataset.passwordVerificando =
                "0";


            passwordEditar.setCustomValidity("");


            passwordEditar.classList.remove(
                "is-invalid"
            );

            passwordEditar.classList.add(
                "is-valid"
            );


            const mensajeValido =
                (
                    resultado.mensajes &&
                    resultado.mensajes.length
                )
                    ?
                    resultado.mensajes.join(" ")
                    :
                    "La contraseña cumple los requisitos de seguridad.";


            mostrarMensajeSeguridadEditar(
                "valido",
                mensajeValido
            );


            actualizarBotonEdicionApicultor();


            return true;


        } catch (error) {

            console.error(
                "Error validando contraseña de edición:",
                error
            );


            passwordEditar.dataset.passwordValidado =
                "0";

            passwordEditar.dataset.passwordVerificando =
                "0";


            const mensaje =
                (
                    "No fue posible verificar la contraseña. "
                    + "Intenta nuevamente."
                );


            passwordEditar.setCustomValidity(
                mensaje
            );


            passwordEditar.classList.remove(
                "is-valid"
            );

            passwordEditar.classList.add(
                "is-invalid"
            );


            mostrarMensajeSeguridadEditar(
                "error",
                mensaje
            );


            actualizarBotonEdicionApicultor();


            return false;

        }

    }


    /* =========================================================
    PROGRAMAR VALIDACIÓN EN VIVO
    ========================================================= */

    function programarValidacionPasswordEditar() {

        clearTimeout(
            temporizadorPasswordEditar
        );


        invalidarPasswordEditar();


        if (
            !passwordEditar ||
            !passwordEditar.value
        ) {

            ocultarMensajeSeguridadEditar();

            return;

        }


        if (
            passwordEditar.value.length < 8
        ) {

            mostrarMensajeSeguridadEditar(
                "error",
                "La contraseña debe tener mínimo 8 caracteres."
            );


            return;

        }


        passwordEditar.dataset.passwordVerificando =
            "1";


        mostrarMensajeSeguridadEditar(
            "verificando",
            "Verificando seguridad de la contraseña..."
        );


        actualizarBotonEdicionApicultor();


        temporizadorPasswordEditar =
            setTimeout(
                async function () {

                    await validarSeguridadPasswordEditar();

                    validarPasswordEditar();

                    actualizarBotonEdicionApicultor();

                },
                400
            );

    }


    /* =========================================================
    EVENTOS DE CONTRASEÑA
    ========================================================= */

    if (passwordEditar) {

        passwordEditar.addEventListener(
            "input",
            function () {

                passwordEditar.setCustomValidity("");

                passwordEditar.classList.remove(
                    "is-valid",
                    "is-invalid"
                );


                programarValidacionPasswordEditar();

                validarPasswordEditar();

                actualizarBotonEdicionApicultor();

            }
        );

    }


    if (confirmarPasswordEditar) {

        confirmarPasswordEditar.addEventListener(
            "input",
            function () {

                validarPasswordEditar();

                actualizarBotonEdicionApicultor();

            }
        );

    }


    /* =========================================================
    SI CAMBIAN DATOS DEL USUARIO, REVALIDAR PASSWORD
    ========================================================= */

    [
        nombresEditar,
        apellidosEditar,
        correoEditar,
        usernameEditar
    ]
        .filter(Boolean)
        .forEach(
            function (campo) {

                campo.addEventListener(
                    "input",
                    function () {

                        if (
                            passwordEditar &&
                            passwordEditar.value
                        ) {

                            programarValidacionPasswordEditar();

                        }
                        else {

                            actualizarBotonEdicionApicultor();

                        }

                    }
                );

            }
        );


    /* =========================================================
    OBSERVAR DUPLICADOS Y CONSULTAS AJAX
    ========================================================= */

    const observadorEstadoEditar =
        new MutationObserver(
            actualizarBotonEdicionApicultor
        );


    observadorEstadoEditar.observe(
        formularioEditar,
        {
            subtree: true,
            attributes: true,
            attributeFilter: [
                "data-duplicado",
                "data-verificando"
            ]
        }
    );


    formularioEditar.addEventListener(
        "input",
        actualizarBotonEdicionApicultor
    );


    /* =========================================================
    ENVÍO DEL FORMULARIO
    ========================================================= */

    formularioEditar.addEventListener(
        "submit",
        async function (evento) {

            // =================================================
            // SEGUNDO ENVÍO
            // =================================================

            if (permitirSiguienteEnvioEditar) {

                permitirSiguienteEnvioEditar =
                    false;


                if (botonGuardar) {

                    botonGuardar.disabled =
                        true;

                    botonGuardar.innerHTML = `
                        <span
                            class="spinner-border spinner-border-sm me-2"
                            aria-hidden="true"
                        ></span>
                        Guardando...
                    `;

                }


                return;

            }


            evento.preventDefault();


            // =================================================
            // VALIDACIONES LOCALES
            // =================================================

            const passwordLocalValido =
                validarPasswordEditar();


            if (
                !passwordLocalValido ||
                !formularioEditar.checkValidity()
            ) {

                formularioEditar.classList.add(
                    "was-validated"
                );

                formularioEditar.reportValidity();

                actualizarBotonEdicionApicultor();


                return;

            }


            const hayDuplicado =
                formularioEditar.querySelector(
                    '[data-duplicado="1"]'
                );


            const hayVerificando =
                formularioEditar.querySelector(
                    '[data-verificando="1"]'
                );


            if (
                hayDuplicado ||
                hayVerificando
            ) {

                actualizarBotonEdicionApicultor();

                return;

            }


            // =================================================
            // SI HAY NUEVA CONTRASEÑA, VALIDACIÓN FINAL DJANGO
            // =================================================

            if (hayCambioPasswordEditar()) {

                const passwordSeguro =
                    await validarSeguridadPasswordEditar();


                if (!passwordSeguro) {

                    passwordEditar.focus();

                    actualizarBotonEdicionApicultor();

                    return;

                }


                if (!validarPasswordEditar()) {

                    confirmarPasswordEditar.focus();

                    actualizarBotonEdicionApicultor();

                    return;

                }

            }


            // =================================================
            // TODO CORRECTO
            // =================================================

            permitirSiguienteEnvioEditar =
                true;


            formularioEditar.requestSubmit();

        }
    );
 
 
    /* =========================================================
       LIMPIAR AL CERRAR
    ========================================================= */
 
    modalEditar.addEventListener(
        "hidden.bs.modal",
        function () {
 
            formularioEditar.reset();
 
            formularioEditar.classList.remove(
                "was-validated"
            );
 
            formularioEditar.action = "";
 
            fotoOriginalEditar = "";
 
            if (inputFotoEditar) {
                inputFotoEditar.value = "";
            }
 
            if (eliminarFotoEditar) {
                eliminarFotoEditar.value = "0";
            }
 
            if (passwordEditar) {

                passwordEditar.value = "";
                passwordEditar.type = "password";
                passwordEditar.setCustomValidity("");


                passwordEditar.dataset.passwordValidado =
                    "0";

                passwordEditar.dataset.passwordVerificando =
                    "0";


                passwordEditar.classList.remove(
                    "is-valid",
                    "is-invalid"
                );

            }
 
            if (confirmarPasswordEditar) {
 
                confirmarPasswordEditar.value = "";
                confirmarPasswordEditar.type = "password";
                confirmarPasswordEditar.setCustomValidity("");
 
                confirmarPasswordEditar.classList.remove(
                    "is-invalid",
                    "is-valid"
                );
 
            }
 
            if (mensajePassword) {
                mensajePassword.classList.add("d-none");
            }

            ocultarMensajeSeguridadEditar();


            clearTimeout(
                temporizadorPasswordEditar
            );


            secuenciaPasswordEditar +=
                1;


            permitirSiguienteEnvioEditar =
                false;
 
            mostrarFotoEditar("");
 
            if (botonGuardar) {
 
                botonGuardar.disabled = true;
 
                botonGuardar.innerHTML = `
                    <i class="bi bi-floppy-fill me-2"></i>
                    Guardar cambios
                `;
 
            }
 
        }
    );
 
 
    /* =========================================================
       FUNCIÓN AUXILIAR
    ========================================================= */
 
    function asignarValor(elemento, valor) {
 
        if (elemento) {
            elemento.value = valor || "";
        }
 
    }
 
});
 
 
document.addEventListener("DOMContentLoaded", function () {
 
    const modalElemento = document.getElementById(
        "modalEliminarApicultor"
    );
 
    const formularioEliminar = document.getElementById(
        "formEliminarApicultor"
    );
 
    const nombreApicultorEliminar = document.getElementById(
        "nombreApicultorEliminar"
    );
 
    const alertaPermitida = document.getElementById(
        "alertaEliminacionPermitida"
    );
 
    const alertaBloqueada = document.getElementById(
        "alertaEliminacionBloqueada"
    );
 
    const mensajeApiarios = document.getElementById(
        "mensajeApiariosEliminar"
    );
 
    const botonConfirmar = document.getElementById(
        "btnConfirmarEliminarApicultor"
    );
 
    /*
    Si alguno de estos elementos no existe, el modal
    no está incluido correctamente en la plantilla.
    */
    if (
        !modalElemento ||
        !formularioEliminar ||
        !botonConfirmar
    ) {
        console.error(
            "No se encontraron los elementos del modal de eliminación."
        );
 
        return;
    }
 
    const modalEliminar = bootstrap.Modal.getOrCreateInstance(
        modalElemento
    );
 
    const botonesEliminar = document.querySelectorAll(
        ".btn-eliminar-apicultor"
    );
 
    botonesEliminar.forEach(function (boton) {
 
        boton.addEventListener("click", function () {
 
            const nombre =
                boton.dataset.nombre || "Apicultor";
 
            const url =
                boton.dataset.url || "";
 
            const cantidadApiarios = Number(
                boton.dataset.apiarios || 0
            );
 
            formularioEliminar.action = url;
 
            if (nombreApicultorEliminar) {
                nombreApicultorEliminar.textContent = nombre;
            }
 
            if (cantidadApiarios > 0) {
 
                if (alertaPermitida) {
                    alertaPermitida.classList.add("d-none");
                }
 
                if (alertaBloqueada) {
                    alertaBloqueada.classList.remove("d-none");
                }
 
                if (mensajeApiarios) {
 
                    if (cantidadApiarios === 1) {
 
                        mensajeApiarios.textContent =
                            "Este apicultor tiene 1 apiario vinculado. " +
                            "Debes reasignarlo antes de eliminar al apicultor.";
 
                    } else {
 
                        mensajeApiarios.textContent =
                            `Este apicultor tiene ${cantidadApiarios} ` +
                            "apiarios vinculados. Debes reasignarlos " +
                            "antes de eliminar al apicultor.";
 
                    }
 
                }
 
                botonConfirmar.disabled = true;
 
                botonConfirmar.innerHTML = `
                    <i class="bi bi-lock-fill me-2"></i>
                    Eliminación bloqueada
                `;
 
            } else {
 
                if (alertaPermitida) {
                    alertaPermitida.classList.remove("d-none");
                }
 
                if (alertaBloqueada) {
                    alertaBloqueada.classList.add("d-none");
                }
 
                botonConfirmar.disabled = false;
 
                botonConfirmar.innerHTML = `
                    <i class="bi bi-trash3-fill me-2"></i>
                    Eliminar definitivamente
                `;
 
            }
 
            modalEliminar.show();
 
        });
 
    });
 
    formularioEliminar.addEventListener(
        "submit",
        function () {
 
            if (botonConfirmar.disabled) {
                return;
            }
 
            botonConfirmar.disabled = true;
 
            botonConfirmar.innerHTML = `
                <span
                    class="spinner-border spinner-border-sm me-2"
                    aria-hidden="true"
                ></span>
                Eliminando...
            `;
 
        }
    );
 
    modalElemento.addEventListener(
        "hidden.bs.modal",
        function () {
 
            formularioEliminar.action = "";
 
            if (nombreApicultorEliminar) {
                nombreApicultorEliminar.textContent = "Apicultor";
            }
 
        }
    );
 
});
 
 
/* =========================================================
   ABRIR AUTOMÁTICAMENTE MODAL NUEVO APICULTOR
========================================================= */
 
document.addEventListener(
    "DOMContentLoaded",
    function () {
 
        const parametros =
            new URLSearchParams(
                window.location.search
            );
 
 
        const abrirNuevo =
            parametros.get(
                "nuevo"
            );
 
 
        if (abrirNuevo !== "1") {
            return;
        }
 
 
        const modalElemento =
            document.getElementById(
                "modalAgregarApicultor"
            );
 
 
        if (
            !modalElemento ||
            typeof bootstrap === "undefined"
        ) {
            return;
        }
 
 
        const modal =
            bootstrap.Modal
                .getOrCreateInstance(
                    modalElemento
                );
 
 
        modal.show();
 
 
        /*
        Quitamos ?nuevo=1 para evitar que el modal
        vuelva a abrirse si el usuario actualiza.
        */
 
        const url =
            new URL(
                window.location.href
            );
 
 
        url.searchParams.delete(
            "nuevo"
        );
 
 
        window.history.replaceState(
            {},
            "",
            url
        );
 
    }
);
 
/* ==========================================================
   VALIDACIONES NUEVAS - MÓDULO DE APICULTORES
   Solo letras en nombres/apellidos, solo números en
   identificación y teléfono, y aviso de correo inválido
   en tiempo real (además de lo que ya validan los atributos
   required / pattern / type="email" del HTML al enviar).
   ========================================================== */
document.addEventListener("DOMContentLoaded", function () {
 
    const SOLO_LETRAS = /[^A-Za-zÀ-ÿ\s]/g;
    const SOLO_NUMEROS = /[^0-9]/g;
    const REGEX_CORREO =
        /^[A-Za-z0-9._%+-]+@(gmail\.com|outlook\.com|hotmail\.com|yahoo\.com)$/i;
 
    // Quita, mientras el usuario escribe, cualquier caracter
    // que no sea letra o espacio.
    function restringirSoloLetras(input) {
        if (!input) return;
 
        input.addEventListener("input", function () {
            const valorFiltrado = this.value.replace(SOLO_LETRAS, "");
            if (valorFiltrado !== this.value) {
                this.value = valorFiltrado;
            }
        });
    }
 
    // Quita, mientras el usuario escribe, cualquier caracter
    // que no sea un dígito.
    function restringirSoloNumeros(input) {
        if (!input) return;
 
        input.addEventListener("input", function () {
            const valorFiltrado = this.value.replace(SOLO_NUMEROS, "");
            if (valorFiltrado !== this.value) {
                this.value = valorFiltrado;
            }
        });
    }
 
    // Marca el campo en rojo si, al salir de él, el correo
    // no tiene un formato válido.
    function validarCorreoEnVivo(
        input
    ) {

        if (!input) {
            return;
        }


        function validar() {

            const valor =
                input.value
                    .trim()
                    .toLowerCase();


            input.setCustomValidity(
                ""
            );


            input.classList.remove(
                "is-valid",
                "is-invalid"
            );


            if (!valor) {

                return;
            }


            if (
                !REGEX_CORREO.test(
                    valor
                )
            ) {

                input.setCustomValidity(
                    (
                        "Usa un correo de Gmail, Outlook, "
                        + "Hotmail o Yahoo."
                    )
                );


                input.classList.add(
                    "is-invalid"
                );


                return;
            }


            input.classList.add(
                "is-valid"
            );

        }


        input.addEventListener(
            "input",
            function () {

                input.value =
                    input.value

                        .replace(
                            /\s/g,
                            ""
                        )

                        .toLowerCase();


                validar();

            }
        );


        input.addEventListener(
            "blur",
            validar
        );

    }
 
    // Años de experiencia: mientras escribe, solo permite dígitos
    // (sin signo negativo ni decimales); al salir del campo, si el
    // número quedó fuera de 0-80, lo ajusta al límite más cercano.
    function restringirExperiencia(input) {
        if (!input) return;
 
        const minimo = Number(input.min) || 0;
        const maximo = Number(input.max) || 80;
 
        input.addEventListener("input", function () {
            const valorFiltrado = this.value.replace(/[^0-9]/g, "");
            if (valorFiltrado !== this.value) {
                this.value = valorFiltrado;
            }
        });
 
        input.addEventListener("blur", function () {
            if (this.value === "") return;
 
            let numero = parseInt(this.value, 10);
 
            if (isNaN(numero)) {
                this.value = "";
                return;
            }
 
            if (numero < minimo) numero = minimo;
            if (numero > maximo) numero = maximo;
 
            this.value = numero;
        });
    }
 
    // ---- Modal Agregar Apicultor ----
    [
        "primerNombreAgregar",
        "segundoNombreAgregar",
        "primerApellidoAgregar",
        "segundoApellidoAgregar"
    ].forEach(function (id) {
        restringirSoloLetras(document.getElementById(id));
    });
 
    [
        "identificacionAgregar",
        "telefonoAgregar"
    ].forEach(function (id) {
        restringirSoloNumeros(document.getElementById(id));
    });
 
    validarCorreoEnVivo(document.getElementById("correoAgregar"));
    restringirExperiencia(document.getElementById("experienciaAgregar"));
 
    // ---- Modal Editar Apicultor ----
    [
        "nombresEditar",
        "apellidosEditar"
    ].forEach(function (id) {
        restringirSoloLetras(document.getElementById(id));
    });
 
    [
        "identificacionEditar",
        "telefonoEditar"
    ].forEach(function (id) {
        restringirSoloNumeros(document.getElementById(id));
    });
 
    validarCorreoEnVivo(document.getElementById("correoEditar"));
    restringirExperiencia(document.getElementById("experienciaEditar"));
 
});
 
/* ==========================================================
   VALIDACIONES COMPLETAS EN VIVO - APICULTORES
========================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        // =====================================================
        // CONFIGURACIÓN
        // =====================================================

        const RETRASO_DEBOUNCE_MS = 400;

        const REGEX_CORREO_PERMITIDO =
            /^[A-Za-z0-9._%+-]+@(gmail\.com|outlook\.com|hotmail\.com|yahoo\.com)$/i;

        const REGEX_IDENTIFICACION =
            /^[0-9]{6,10}$/;

        const REGEX_TELEFONO =
            /^3[0-9]{9}$/;

        const REGEX_USERNAME =
            /^[A-Za-z0-9_@.+-]{1,150}$/;

        const REGEX_NOMBRE =
            /^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' -]+$/;


        // =====================================================
        // OBTENER / CREAR MENSAJE DE VALIDACIÓN
        // =====================================================

        function obtenerFeedback(
            campo
        ) {

            if (!campo) {
                return null;
            }


            const idFeedback =
                `feedback-${campo.id}`;


            let feedback = (
                document.getElementById(
                    idFeedback
                )
            );


            if (feedback) {
                return feedback;
            }


            feedback = (
                document.createElement(
                    "small"
                )
            );


            feedback.id =
                idFeedback;


            feedback.className =
                "d-block mt-1";


            const grupo = (
                campo.closest(
                    ".input-group-apicultor"
                )
            );


            if (grupo) {

                grupo.insertAdjacentElement(
                    "afterend",
                    feedback
                );

            } else {

                campo.insertAdjacentElement(
                    "afterend",
                    feedback
                );

            }


            return feedback;

        }


        // =====================================================
        // MOSTRAR ESTADO
        // =====================================================

        function mostrarEstado(
            campo,
            estado,
            mensaje
        ) {

            if (!campo) {
                return;
            }


            campo.classList.remove(
                "is-valid",
                "is-invalid"
            );


            const feedback = (
                obtenerFeedback(
                    campo
                )
            );


            if (feedback) {

                feedback.classList.remove(
                    "text-success",
                    "text-danger",
                    "text-muted"
                );

            }


            // -------------------------------------------------
            // NEUTRO
            // -------------------------------------------------

            if (
                estado === "neutro"
            ) {

                campo.setCustomValidity(
                    ""
                );


                if (feedback) {

                    feedback.textContent =
                        mensaje || "";


                    if (mensaje) {

                        feedback.classList.add(
                            "text-muted"
                        );

                    }

                }


                return;

            }


            // -------------------------------------------------
            // VÁLIDO
            // -------------------------------------------------

            if (
                estado === "valido"
            ) {

                campo.classList.add(
                    "is-valid"
                );


                campo.setCustomValidity(
                    ""
                );


                if (feedback) {

                    feedback.textContent =
                        mensaje || "Dato válido.";


                    feedback.classList.add(
                        "text-success"
                    );

                }


                return;

            }


            // -------------------------------------------------
            // INVÁLIDO
            // -------------------------------------------------

            campo.classList.add(
                "is-invalid"
            );


            campo.setCustomValidity(
                mensaje || "Dato inválido."
            );


            if (feedback) {

                feedback.textContent =
                    mensaje || "Dato inválido.";


                feedback.classList.add(
                    "text-danger"
                );

            }

        }


        // =====================================================
        // DEBOUNCE
        // =====================================================

        function debounce(
            funcion,
            espera
        ) {

            let temporizador = null;


            return function (...args) {

                const contexto = this;


                clearTimeout(
                    temporizador
                );


                temporizador = setTimeout(
                    function () {

                        funcion.apply(
                            contexto,
                            args
                        );

                    },
                    espera
                );

            };

        }


        // =====================================================
        // SOLO NÚMEROS + LONGITUD MÁXIMA
        // =====================================================

        function limitarNumeros(
            campo,
            maximo
        ) {

            if (!campo) {
                return;
            }


            campo.addEventListener(
                "input",
                function () {

                    campo.value = (
                        campo.value
                            .replace(
                                /\D/g,
                                ""
                            )
                            .slice(
                                0,
                                maximo
                            )
                    );

                }
            );

        }


        // =====================================================
        // NOMBRES Y APELLIDOS
        // =====================================================

        function configurarNombre(
            campo,
            obligatorio = false
        ) {

            if (!campo) {
                return;
            }


            campo.addEventListener(
                "input",
                function () {

                    // Eliminar caracteres
                    // que no pertenecen a nombres.
                    campo.value = (
                        campo.value.replace(
                            /[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ' -]/g,
                            ""
                        )
                    );


                    const valor =
                        campo.value.trim();


                    if (!valor) {

                        mostrarEstado(
                            campo,
                            obligatorio
                                ? "invalido"
                                : "neutro",
                            obligatorio
                                ? "Este campo es obligatorio."
                                : ""
                        );

                        return;

                    }


                    if (
                        valor.length < 2
                    ) {

                        mostrarEstado(
                            campo,
                            "invalido",
                            "Debe contener al menos 2 caracteres."
                        );

                        return;

                    }


                    if (
                        !REGEX_NOMBRE.test(
                            valor
                        )
                    ) {

                        mostrarEstado(
                            campo,
                            "invalido",
                            "Usa solamente letras, espacios, apóstrofes o guiones."
                        );

                        return;

                    }


                    mostrarEstado(
                        campo,
                        "valido",
                        "Nombre válido."
                    );

                }
            );

        }


        // =====================================================
        // TELÉFONO COLOMBIANO
        // =====================================================

        function configurarTelefono(
            campo
        ) {

            if (!campo) {
                return;
            }


            limitarNumeros(
                campo,
                10
            );


            campo.addEventListener(
                "input",
                function () {

                    const valor =
                        campo.value.trim();


                    // Sigue siendo opcional
                    if (!valor) {

                        mostrarEstado(
                            campo,
                            "neutro",
                            ""
                        );

                        return;

                    }


                    if (
                        valor.charAt(0) !== "3"
                    ) {

                        mostrarEstado(
                            campo,
                            "invalido",
                            "El número celular debe comenzar por 3."
                        );

                        return;

                    }


                    if (
                        valor.length < 10
                    ) {

                        const faltan =
                            10 - valor.length;


                        mostrarEstado(
                            campo,
                            "invalido",
                            `Faltan ${faltan} número(s). Debe tener exactamente 10.`
                        );

                        return;

                    }


                    if (
                        !REGEX_TELEFONO.test(
                            valor
                        )
                    ) {

                        mostrarEstado(
                            campo,
                            "invalido",
                            "El teléfono no es válido."
                        );

                        return;

                    }


                    mostrarEstado(
                        campo,
                        "valido",
                        "Número celular válido."
                    );

                }
            );

        }


        // =====================================================
        // IDENTIFICACIÓN
        // =====================================================

        function validarIdentificacionLocal(
            campo
        ) {

            const valor =
                campo.value.trim();


            if (!valor) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "La identificación es obligatoria."
                );

                return false;

            }


            if (
                valor.length < 6
            ) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "La identificación debe tener mínimo 6 números."
                );

                return false;

            }


            if (
                !REGEX_IDENTIFICACION.test(
                    valor
                )
            ) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "La identificación debe contener entre 6 y 10 números."
                );

                return false;

            }


            return true;

        }


        // =====================================================
        // CORREO ELECTRÓNICO
        // =====================================================

        function validarCorreoLocal(
            campo
        ) {

            let valor =
                campo.value.trim();


            // Normalizar a minúsculas
            valor =
                valor.toLowerCase();


            campo.value =
                valor;


            // -------------------------------------------------
            // OBLIGATORIO
            // -------------------------------------------------

            if (!valor) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "El correo electrónico es obligatorio."
                );


                return false;

            }


            // -------------------------------------------------
            // LONGITUD
            // -------------------------------------------------

            if (
                valor.length >
                254
            ) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "El correo electrónico no puede superar los 254 caracteres."
                );


                return false;

            }


            // -------------------------------------------------
            // PROVEEDORES PERMITIDOS
            // -------------------------------------------------

            if (
                !REGEX_CORREO_PERMITIDO.test(
                    valor
                )
            ) {

                mostrarEstado(
                    campo,
                    "invalido",
                    (
                        "Usa un correo de Gmail, Outlook, "
                        + "Hotmail o Yahoo."
                    )
                );


                return false;

            }


            // -------------------------------------------------
            // FORMATO CORRECTO
            // -------------------------------------------------

            mostrarEstado(
                campo,
                "valido",
                "Formato de correo válido."
            );


            return true;

        }


        // =====================================================
        // USERNAME
        // =====================================================

        function validarUsernameLocal(
            campo
        ) {

            const valor =
                campo.value.trim();


            if (!valor) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "El nombre de usuario es obligatorio."
                );

                return false;

            }


            if (
                !REGEX_USERNAME.test(
                    valor
                )
            ) {

                mostrarEstado(
                    campo,
                    "invalido",
                    "Solo se permiten letras, números y @ . + - _"
                );

                return false;

            }


            return true;

        }


        // =====================================================
        // EXTRAER ID DEL APICULTOR EDITADO
        // =====================================================

        const formEditar = (
            document.getElementById(
                "formEditarApicultor"
            )
        );


        const modalEditar = (
            document.getElementById(
                "modalEditarApicultor"
            )
        );


        if (
            modalEditar
            &&
            formEditar
        ) {

            modalEditar.addEventListener(
                "show.bs.modal",
                function (evento) {

                    const boton =
                        evento.relatedTarget;


                    formEditar.dataset
                        .idApicultor = (
                            boton
                            ?
                            (
                                boton.dataset.id
                                ||
                                ""
                            )
                            :
                            ""
                        );

                }
            );

        }


        // =====================================================
        // CONSULTAR DUPLICADOS
        // =====================================================

        function verificarEnServidor(
            campo,
            tipoCampo,
            formulario,
            mensajeDisponible
        ) {

            const valorOriginal =
                campo.value.trim();


            if (!valorOriginal) {
                return;
            }


            const idApicultor = (
                formulario
                &&
                formulario.id ===
                    "formEditarApicultor"
            )
                ?
                (
                    formulario.dataset
                        .idApicultor
                    ||
                    ""
                )
                :
                "";


            let url =
                URL_VERIFICAR_DATO_APICULTOR
                +
                "?campo="
                +
                encodeURIComponent(
                    tipoCampo
                )
                +
                "&valor="
                +
                encodeURIComponent(
                    valorOriginal
                );


            if (idApicultor) {

                url += (
                    "&id_apicultor="
                    +
                    encodeURIComponent(
                        idApicultor
                    )
                );

            }

            campo.dataset.verificando =
                "1";

            mostrarEstado(
                campo,
                "neutro",
                "Verificando disponibilidad..."
            );


            fetch(
                url
            )
                .then(
                    function (
                        respuesta
                    ) {

                        if (
                            !respuesta.ok
                        ) {

                            throw new Error(
                                "Error HTTP."
                            );

                        }


                        return respuesta.json();

                    }
                )
                .then(
                    function (
                        datos
                    ) {

                        // El usuario siguió escribiendo
                        // mientras llegaba la respuesta.
                        if (
                            campo.value.trim()
                            !==
                            valorOriginal
                        ) {

                            return;

                        }

                        campo.dataset.verificando =
                            "0";


                        if (
                            datos.valido === false
                        ) {

                            campo.dataset.verificando =
                                "0";

                            campo.dataset.duplicado =
                                "0";


                            mostrarEstado(
                                campo,
                                "invalido",
                                datos.mensaje
                                ||
                                "Dato inválido."
                            );


                            return;

                        }


                        if (
                            datos.existe
                        ) {

                            campo.dataset.duplicado =
                                "1";


                            mostrarEstado(
                                campo,
                                "invalido",
                                datos.mensaje
                                ||
                                "Este dato ya está registrado."
                            );


                            return;

                        }


                        campo.dataset.duplicado =
                            "0";


                        mostrarEstado(
                            campo,
                            "valido",
                            datos.mensaje
                            ||
                            mensajeDisponible
                        );

                    }
                )
                .catch(
                    function (
                        error
                    ) {

                        console.error(
                            "Error verificando dato:",
                            error
                        );

                        campo.dataset.verificando =
                            "0";

                        // No afirmamos que está disponible
                        // si no pudimos consultar el servidor.
                        campo.dataset.duplicado =
                            "0";


                        mostrarEstado(
                            campo,
                            "neutro",
                            "No fue posible comprobar disponibilidad."
                        );

                    }
                );

        }


        // =====================================================
        // ACTIVAR VALIDACIÓN ÚNICA EN VIVO
        // =====================================================

        function configurarCampoUnico(
            campo,
            tipoCampo,
            formulario,
            validarLocal,
            mensajeDisponible
        ) {

            if (!campo) {
                return;
            }


            const consultarConRetraso =
                debounce(
                    function () {

                        verificarEnServidor(
                            campo,
                            tipoCampo,
                            formulario,
                            mensajeDisponible
                        );

                    },
                    RETRASO_DEBOUNCE_MS
                );


            campo.addEventListener(
                "input",
                function () {

                    campo.dataset.duplicado =
                        "0";

                    campo.dataset.verificando =
                        "0";


                    const esValido =
                        validarLocal(
                            campo
                        );


                    if (!esValido) {

                        return;

                    }


                    campo.dataset.verificando =
                        "1";


                    mostrarEstado(
                        campo,
                        "neutro",
                        "Formato válido. Verificando..."
                    );


                    consultarConRetraso();

                }
            );

        }


        // =====================================================
        // FORMULARIOS
        // =====================================================

        const formAgregar = (
            document.getElementById(
                "formAgregarApicultor"
            )
        );


        // =====================================================
        // NOMBRES - AGREGAR
        // =====================================================

        configurarNombre(
            document.getElementById(
                "primerNombreAgregar"
            ),
            true
        );


        configurarNombre(
            document.getElementById(
                "segundoNombreAgregar"
            ),
            false
        );


        configurarNombre(
            document.getElementById(
                "primerApellidoAgregar"
            ),
            true
        );


        configurarNombre(
            document.getElementById(
                "segundoApellidoAgregar"
            ),
            false
        );


        // =====================================================
        // NOMBRES - EDITAR
        // =====================================================

        configurarNombre(
            document.getElementById(
                "nombresEditar"
            ),
            true
        );


        configurarNombre(
            document.getElementById(
                "apellidosEditar"
            ),
            true
        );


        // =====================================================
        // TELÉFONO
        // =====================================================

        configurarTelefono(
            document.getElementById(
                "telefonoAgregar"
            )
        );


        configurarTelefono(
            document.getElementById(
                "telefonoEditar"
            )
        );


        // =====================================================
        // IDENTIFICACIÓN
        // =====================================================

        const identificacionAgregar =
            document.getElementById(
                "identificacionAgregar"
            );


        const identificacionEditar =
            document.getElementById(
                "identificacionEditar"
            );


        limitarNumeros(
            identificacionAgregar,
            10
        );


        limitarNumeros(
            identificacionEditar,
            10
        );


        configurarCampoUnico(
            identificacionAgregar,
            "identificacion",
            formAgregar,
            validarIdentificacionLocal,
            "Identificación disponible."
        );


        configurarCampoUnico(
            identificacionEditar,
            "identificacion",
            formEditar,
            validarIdentificacionLocal,
            "Identificación disponible."
        );


        // =====================================================
        // CORREO ELECTRÓNICO
        // =====================================================

        configurarCampoUnico(
            document.getElementById(
                "correoAgregar"
            ),
            "correo",
            formAgregar,
            validarCorreoLocal,
            "Correo electrónico disponible."
        );


        configurarCampoUnico(
            document.getElementById(
                "correoEditar"
            ),
            "correo",
            formEditar,
            validarCorreoLocal,
            "Correo electrónico disponible."
        );


        // =====================================================
        // USERNAME
        // =====================================================

        configurarCampoUnico(
            document.getElementById(
                "usernameAgregar"
            ),
            "username",
            formAgregar,
            validarUsernameLocal,
            "Nombre de usuario disponible."
        );


        configurarCampoUnico(
            document.getElementById(
                "usernameEditar"
            ),
            "username",
            formEditar,
            validarUsernameLocal,
            "Nombre de usuario disponible."
        );


        // =====================================================
        // EXPERIENCIA
        // =====================================================

        [
            document.getElementById(
                "experienciaAgregar"
            ),
            document.getElementById(
                "experienciaEditar"
            )
        ]
        .forEach(
            function (
                campo
            ) {

                if (!campo) {
                    return;
                }


                campo.addEventListener(
                    "input",
                    function () {

                        campo.value = (
                            campo.value
                                .replace(
                                    /\D/g,
                                    ""
                                )
                        );


                        if (!campo.value) {

                            mostrarEstado(
                                campo,
                                "neutro",
                                ""
                            );

                            return;

                        }


                        const numero =
                            Number(
                                campo.value
                            );


                        if (
                            numero < 0
                            ||
                            numero > 80
                        ) {

                            mostrarEstado(
                                campo,
                                "invalido",
                                "La experiencia debe estar entre 0 y 80 años."
                            );

                            return;

                        }


                        mostrarEstado(
                            campo,
                            "valido",
                            "Experiencia válida."
                        );

                    }
                );

            }
        );


        // =====================================================
        // BLOQUEAR ENVÍO CON DATOS INVÁLIDOS
        // =====================================================

        [
            formAgregar,
            formEditar
        ]
        .forEach(
            function (
                formulario
            ) {

                if (!formulario) {
                    return;
                }


                formulario.addEventListener(
                    "submit",
                    function (
                        evento
                    ) {

                        const duplicado = (
                            formulario.querySelector(
                                '[data-duplicado="1"]'
                            )
                        );


                        if (
                            duplicado
                            ||
                            !formulario.checkValidity()
                        ) {

                            evento.preventDefault();

                            evento.stopPropagation();


                            if (duplicado) {

                                duplicado.reportValidity();

                            } else {

                                formulario.reportValidity();

                            }

                        }

                    }
                );

            }
        );

    }
);